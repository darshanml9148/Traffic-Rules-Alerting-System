import React, { useEffect, useState } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import { baseurl } from "./App";

const ManageRules = () => {
  const [rules, setRules] = useState([]);

  const [ruleid, setRuleid] = useState("");
  const [rule, setRule] = useState("");
  const [latitude, setLatitude] = useState("");
  const [longitude, setLongitude] = useState("");
  const [value, setValue] = useState(0);
  const [imageBase64, setImageBase64] = useState("");
  const [editing, setEditing] = useState(false);

  const fetchRules = async () => {
    try {
      const res = await axios.post(
        baseurl,
        new URLSearchParams({ tag: "get_rules" }),
        { headers: { "Content-Type": "application/x-www-form-urlencoded" } }
      );
      if (res.data.error === 0) {
        setRules(res.data.rules);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => setImageBase64(reader.result);
    reader.readAsDataURL(file);
  };

  const clearForm = () => {
    setRuleid("");
    setRule("");
    setLatitude("");
    setLongitude("");
    setValue("");
    setImageBase64("");
    setEditing(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (
      !rule ||
      !latitude ||
      !longitude ||
      !value ||
      (!imageBase64 && !editing)
    ) {
      alert("Please fill all fields and upload an image.");
      return;
    }

    const postData = new URLSearchParams({
      tag: editing ? "update_rule" : "add_rules",
      ruleid: editing ? ruleid : "",
      rule,
      latitude,
      longitude,
      value,
      board: imageBase64,
    });

    try {
      const res = await axios.post(baseurl, postData, {
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
      });
      alert(res.data.message);
      clearForm();
      fetchRules();
    } catch (err) {
      console.error(err);
    }
  };

  const handleEdit = (r) => {
    setRuleid(r.ruleid);
    setRule(r.rule);
    setLatitude(r.latitude);
    setLongitude(r.longitude);
    setValue(r.value);
    setImageBase64(r.board);
    setEditing(true);
  };

  const handleDelete = async (ruleid) => {
    if (!window.confirm("Delete this rule?")) return;

    try {
      const res = await axios.post(
        baseurl,
        new URLSearchParams({ tag: "delete_rule", ruleid: ruleid }),
        { headers: { "Content-Type": "application/x-www-form-urlencoded" } }
      );
      alert(res.data.message);
      fetchRules();
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchRules();
  }, []);

  return (
    <div className="container mt-5">
      <h2 className="mb-4">{editing ? "Update Rule" : "Add Rule"}</h2>
      <form onSubmit={handleSubmit} className="row g-3">
        <div className="col-md-6">
          <input
            type="text"
            className="form-control"
            placeholder="Enter Rule"
            value={rule}
            onChange={(e) => setRule(e.target.value)}
            required
          />
        </div>
        <div className="col-md-6">
          <input
            type="text"
            className="form-control"
            placeholder="Latitude"
            value={latitude}
            onChange={(e) => setLatitude(e.target.value)}
            required
          />
        </div>
        <div className="col-md-6">
          <input
            type="text"
            className="form-control"
            placeholder="Longitude"
            value={longitude}
            onChange={(e) => setLongitude(e.target.value)}
            required
          />
        </div>
        <div className="col-md-6">
          <input
            type="text"
            className="form-control"
            placeholder="Value"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            required
          />
        </div>
        <div className="col-md-6">
          <input
            className="form-control"
            type="file"
            accept="image/*"
            onChange={handleImageChange}
          />
        </div>
        {imageBase64 && (
          <div className="col-md-12">
            <img
              src={imageBase64}
              alt="Preview"
              className="img-thumbnail"
              width="100"
            />
          </div>
        )}
        <div className="col-12">
          <button type="submit" className="btn btn-primary me-2">
            {editing ? "Update" : "Add"}
          </button>
          {editing && (
            <button
              type="button"
              className="btn btn-secondary"
              onClick={clearForm}
            >
              Cancel
            </button>
          )}
        </div>
      </form>

      <h3 className="mt-5">All Rules</h3>
      <div className="table-responsive">
        <table className="table table-bordered mt-3">
          <thead className="table-light">
            <tr>
              <th>ID</th>
              <th>Rule</th>
              <th>Lat</th>
              <th>Long</th>
              <th>Value</th>
              <th>Image</th>
              <th>Map</th> 
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {rules.map((r) => (
              <tr key={r.ruleid}>
                <td>{r.ruleid}</td>
                <td>{r.rule}</td>
                <td>{r.latitude}</td>
                <td>{r.longitude}</td>
                <td>{r.value}</td>
                <td>
                  {r.board && <img src={r.board} alt="rule" width="60" />}
                </td>
                <td>
                  <a
                    href={`https://www.google.com/maps?q=${r.latitude},${r.longitude}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-sm btn-info"
                    title="View Map"
                  >
                    🗺️
                  </a>
                </td>
                <td>
                  <button
                    className="btn btn-sm btn-warning me-2"
                    onClick={() => handleEdit(r)}
                  >
                    Edit
                  </button>
                  <button
                    className="btn btn-sm btn-danger"
                    onClick={() => handleDelete(r.ruleid)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
            {rules.length === 0 && (
              <tr>
                <td colSpan="8" className="text-center">
                  No rules available
                </td>
              </tr>
            )}
          </tbody>

        </table>
      </div>
    </div>
  );
};

export default ManageRules;
