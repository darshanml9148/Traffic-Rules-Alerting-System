import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./Home";
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import Login from "./Login";
import './App.css';
import Dashboard from "./Dashboard";
import ManageRules from "./MangeRules";

// export const baseurl = "http://192.168.1.12:8888/API/trafficrulesAPI.php";
export const baseurl = "https://yhmysore.in/api/trafficrulesAPI.php"

export default function App(){
  return (
    <>
    <BrowserRouter>
    <Routes>
    <Route path="/" element={<Home/>} />
    <Route path="/login" element={<Login/>} />
    <Route path="/dashboard" element={<Dashboard/>} >

    <Route path="rules" element={<ManageRules/>} />

    </Route>

    </Routes>
    </BrowserRouter>
    
    </>
  )
}