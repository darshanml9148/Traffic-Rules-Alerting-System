import { Link, Outlet, useLocation } from "react-router-dom";
import Image from '../src/Image/dashboard.jpg'


export default function Dashboard() {

  const admin = sessionStorage.getItem('user');
    const location = useLocation();

  const logout = () => {
    sessionStorage.removeItem('user');
  }

  if (!admin) {
    return (
      <div className="container">
        <h2 className="text-center mt-5">Please Login to Continue</h2>
      </div>
    )
  }
  const isDashboardPage = location.pathname === '/dashboard';
    return (
        <>
        <nav className="navbar navbar-dark bg-dark navbar-expand-lg">
        <div className="container">
          <Link className="navbar-brand" to="/dashboard">
          Traffic Rules Notification System
          </Link>
           <div className="collapse navbar-collapse">
                      <ul className="navbar-nav ms-auto">
                        <li className="nav-item">
                          <Link className="nav-link" to="rules">
                            Manage Rules
                          </Link>
                        </li>
                        <li className="nav-item">
                          <Link className="nav-link" to="/" onClick={logout}>
                            Logout
                          </Link>
                        </li>
                      </ul>
                    </div>
    
        </div>
      </nav>
      <div>
      {isDashboardPage && (
        <div className="container my-4">
           <h2 className="text-center mt-5">Welcome to Admin Dashboard</h2>
           <h4 className="text-center mt-2 mb-4">Manage Traffic Rules and Notifications</h4>
          <img src={Image} alt=""  width="100%" />
        </div>
      )}
      </div>
      <Outlet />
        </>

    )
    }