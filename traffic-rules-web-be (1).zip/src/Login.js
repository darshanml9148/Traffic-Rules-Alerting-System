import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { baseurl } from "./App";


export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!username ) {
      alert('Please enter username');
      return;
    }
    if (!password ) {
      alert('Please enter password');
      return;
    }

    try {
      const response = await axios.post(
        baseurl,
        new URLSearchParams({
          tag: "admin_login",
          username: username,
          password : password,

        }),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        }
      );
      if (response.data.error === 0) {
        sessionStorage.setItem('user',username);
        alert("Login successfully");
          navigate('/dashboard');
          setUsername("")
          setPassword("");
      } else {
        alert(response.data.message || "Error");
        console.log(response)
      }
    } catch (error) {
      alert(error.message );
    }
  };

  return (
    <div>
      <div className="login-container">
        <div className="card w-50 mx-auto p-4 mt-5 shadow ">
          <h2 className=" text-center">Login</h2>
          <form>
            <label>Username :</label>
            <input
              type="text"
              value={username}
              className="form-control mb-3"
              onChange={(e) => setUsername(e.target.value)}
            />
            <label>Password</label>
            <input
              type="password"
              value={password}
              className="form-control mb-3"
              onChange={(e) => setPassword(e.target.value)}
            />
            <div className="d-flex gap-4 mx-auto ">
              <button className="btn btn-warning" onClick={handleLogin}>
                Login
              </button>
              <Link className="btn btn-secondary" to="/">
                Back
              </Link>
            </div>
          </form>

        </div>
      </div>
    </div>
  );
}
